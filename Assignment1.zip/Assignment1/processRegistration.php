<?php 
require "autoload.php";
require "config.php";
class Registration
{
	protected $error = [];

	public function run()
	{
		echo "hello";

		if(isset($_POST))
		{
			$validation = new ValidateController();
			if($validation->SignUpValidation($_POST) == true)
			{
				if($_POST['uzrPass'] == $_POST['formRetypePWD'])
				{

					$FILE = fopen("/data/users.json", "a") or die("Unable to open file!");

					$hashedPassword = password_hash($_POST['uzrPass'], PASSWORD_DEFAULT);
					$userName = $_POST['formFullName'];
					$userEmail = $_POST['uzrPass'];
			        $jsonarr = array( array("Name" => "$userName", "Email" => "$userEmail", "Password" => $hashedPassword)); 
				        $dump = json_encode($jsonarr);
				        
				        fwrite($FILE, $dump);
				        fclose($myfile);

				}
				else
				{
					echo "error";
					$this->error['pwdmatch'] = 'error occured passwords dont match';
					$SController = new SignupController();
					$SController->run();
				}
			}
			else
			{
				echo "reg validation error";
				$this->error['regvalidation'] = 'error occured registration validation failed';
				$SController = new SignupController();
				$SController->run();
			}
	    }
	    else
	    {
	    	echo "no data submitted";
	    	$this->error['reg'] = 'error occured no data was submitted';
	    	$SController = new SignupController();
			$SController->run();
	    }
	}	
}

if(isset($_POST['signup']))
	{
		echo " yo";
		Registration::run();
	}
	else
	{
		echo "no";
	}

?>
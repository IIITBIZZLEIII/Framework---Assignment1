<?php
class View implements Observer_Interface
{
	private $vari = [];
	private $tpl = '';

	public function setTemplate(string $filename)
	{
		if(empty($filename))
		{
			trigger_error('No Template File Given', E_USER_ERROR);
			exit;
		}
		elseif(!file_exists($filename))
		{
			trigger_error('File ' .$filename. ' does not exist', E_USER_ERROR);
			exit;
		}
		$this->tpl = $filename;
	}

	public function addVar(string $name, $value)
	{
		if(preg_match('/^[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$/', $name) == 0)
		{
			trigger_error("Incorrect name used ", E_USER_ERROR);
		}
		$this->vari[$name] = $value;
	}

	public function display()
	{
		extract($this->vari);
		require $this->tpl;
	}

	public function update(Observable_Model $obs)
	{
		$records = $obs->giveUpdate();
		foreach($records as $n=>$v)
		{
			$this->addVar($n, $v);
		}
		$this->display();
	}

	public function ImportVars(array $variables)
	{
		if(empty($variables))
		{
			trigger_error("Variable Array empty", E_USER_ERROR);
		}
		foreach ($variables as $name => $value) 
		{
			$this->vars[$name] = $value;
		}
	}
}
?>
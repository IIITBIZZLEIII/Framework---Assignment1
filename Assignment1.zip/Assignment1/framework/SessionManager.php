<?php

class SessionManager
{
	protected $access = ['profile'=>['tester@comp3170.com', 'YaboiSteve@outlook.com', 'SteveC@hotmail.com'],'courses'=>['tester@comp3170.com', 'YaboiSteve@outlook.com', 'SteveC@hotmail.com'] ];

	public static function create()
	{
		session_start();
	}

	public static function destroy()
	{
		session_start();
		if(isset($_SESSION["user"]))
		{
			setcookie(session_id(), "", time() - 3600);
			session_unset();
			session_destroy();
			session_write_close();
			//var_dump($_SESSION);
			$controller = new IndexController();
			$controller->run();
		}
		echo "error";
	}

	public static function add(string $name, $value)
	{
		if(preg_match('/^[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$/', $name) == 0)
		{
			trigger_error("Incorrect name used for session", E_USER_ERROR);
		}
		$_SESSION[$name] = $value;
	}

	public static function remove(string $name)
	{
		unset($_SESSION[$name]);
	}

	public function getUser(string $name)
	{
		if(isset($_SESSION[$name]))
		{
			return $_SESSION[$name];
		}
		return null;
	}

	public function accessible(string $user, $page)
	{
		if(in_array($user, $this->access[$page]))
		{
			return true;
		}
		return false;
	}
	

}

?>
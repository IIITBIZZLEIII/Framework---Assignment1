<?php
require 'autoload.php';
require 'config.php';

$vController = new ValidateController();
$vController->run();

?>
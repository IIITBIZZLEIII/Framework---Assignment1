<?php

const rootdir = 'c:/xampp2/htdocs/Assignment1';
const tempdir = rootdir . '/tpl';
const ddir = rootdir . '/data';

?>
<?php
require 'autoload.php';
require 'config.php';

if((isset($_GET['controller'])) && ($_GET['controller'] == "Logout"))
{
	$SManager = new SessionManager();
	$SManager->destroy();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "Courses"))
{
	$CController = new CoursesController();
	$CController->run();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "Profile"))
{
	$PController = new ProfileController();
	$PController->run();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "SignUp"))
{
	$SController = new SignupController();
	$SController->run();
}
elseif((isset($_GET['controller'])) && ($_GET['controller'] == "Login"))
{
	$lcontroller = new LoginController();
	$lcontroller->run();
}	
else
{
	$controller = new IndexController();
	$controller->run();
}


?>
<?php
class CoursesController extends Controller_Abstract
{

	public function run()
	{
		$SManager = new SessionManager();
		$SManager->create();
		$cview = new View();
		$cview->setTemplate(tempdir. '/courses.tpl.php');
		$this->setView($cview);
		$this->setModel(new CoursesModel());
		$this->model->attach($this->view);

		//var_dump($_SESSION);
		//checks whether the variable user in the session vairable exist
		$user = $SManager->getUser('user');

		if(!($user == NULL) && ($SManager->accessible($user, 'courses')))
		{
			//to acquire the courses the user is registered for
			$pdata = $this->model->getAll();

			//to inform the model to update the data that has been changed
			$this->model->Updatedata($pdata);

			//to inform the model to notify its observers of changes
			$this->model->notify();
		}
		else
		{
			unset($_POST);
			$LController = new LoginController();
			$LController->run();
		}
	}
}
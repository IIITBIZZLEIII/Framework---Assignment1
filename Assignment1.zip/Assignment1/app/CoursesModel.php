<?php
class CoursesModel extends Observable_Model
{
	public function getAll() : array
	{
		$ccdata = $this->LoadData(ddir . '/courses.json');
		//$cidata = $this->LoadData(ddir . '')

		return ['courses' => $ccdata['courses']];
	}

	public function getRecord(string $id) : array
	{
		return [];
	}




}

?>
<?php

class IndexController extends Controller_Abstract
{
	public function run()
	{
		$iview = new View();
		$iview->setTemplate(tempdir . '/index.tpl.php');
		$this->setView ($iview);
		$this->setModel(new IndexModel());
		$this->model->attach($this->view);

		$idata = $this->model->getAll();

		$this->model->Updatedata($idata);

		$this->model->notify();
	}
}

?>
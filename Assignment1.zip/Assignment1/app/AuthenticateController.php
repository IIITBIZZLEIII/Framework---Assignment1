<?php
class AuthenticateController extends AbstractController
{
	protected function makeView() : View
	{
	$blnkview = new View();
	return $blnkview;
	}

	public function run()
	{

	}
}
?>
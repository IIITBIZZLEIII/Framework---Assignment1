<?php

class IndexModel extends Observable_Model
{
	public function getAll() : array
	{
		$idata = $this->LoadData(ddir . '/courses.json');

		$popcolumn = array_column($idata['courses'], 3);
		$reccolumn = array_column($idata['courses'], 2);
		$arraycopy = $idata['courses'];

		array_multisort($reccolumn, SORT_DESC, $idata['courses']);
		$rec = array_slice($idata['courses'], 0, 8);

		array_multisort($popcolumn, SORT_DESC, $arraycopy);
		$pop = array_slice($arraycopy, 0, 8);

		return ['recommended'=>$rec, 'popular'=>$pop];
	}

	public function getRecord(string $id) : array
	{
		return [];
		/*$singledata - $this->LoadData(ddir . '/.json');

		if(empty($id))
		{
			trigger_error("No Identifier was specified", E_USER_ERROR);
		}

		else
		{

		}*/
	}
}

?>